import React from 'react'

const Obi = () => {
  return (
    <div>
        <h1>These aren't the droids you're looking for...</h1>
        <img width={300} src="https://img.brickowl.com/files/image_cache/larger/lego-obi-wan-kenobi-old-minifigure-28.jpg" alt="Lego Obi-Wan Kenobi" />
    </div>
  )
}

export default Obi