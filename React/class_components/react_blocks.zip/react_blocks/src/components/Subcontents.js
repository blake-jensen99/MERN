import React, {Component} from "react";
import styles from "./Style.module.css"

class Subcontents extends Component {


    render(){
        return(
            <div className={styles.sub}></div>
        )
    }
}

export default Subcontents