import React, {Component} from "react";
import styles from "./Style.module.css"

class Advertisement extends Component {


    render(){
        return(
            <div className={styles.ad}></div>
        )
    }
}

export default Advertisement