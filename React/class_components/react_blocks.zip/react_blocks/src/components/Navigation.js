import React, {Component} from "react";
import styles from "./Style.module.css"

class Navigation extends Component {


    render(){
        return(
            <div className={styles.nav}></div>
        )
    }
}

export default Navigation