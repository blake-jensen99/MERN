import React, {Component} from "react";
import styles from "./Style.module.css"

class Header extends Component {


    render(){
        return(
            <div className={styles.header}></div>
        )
    }
}

export default Header