import Tab from './components/tabs';
import './App.css';

function App() {
  return (
    <div className="App">
      <Tab />
    </div>
  );
}

export default App;
