
import './App.css';
import Todo from './components/Todo';
import View from './views/View';

function App() {
  return (
    <div className="App">
      <View />
    </div>
  );
}

export default App;
